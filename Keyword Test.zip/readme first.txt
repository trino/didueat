The "Keyword Test" folder must go in the same directory as your "veritas3-1" folder (it gets the database username/password from that project's config file)

So your directory structure will be like:

\wamp
 \----www
      \----veritas3-1
      \----Keyword Test

Then navigate to:
http://localhost/keyword%20test/

The "Click to Speak" button will only show on Chrome, as it's the only browser with working speech recognition